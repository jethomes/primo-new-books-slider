  var slider = tns({
    container: '.booklist',
    items: 12,
    slideBy: 10,
    "nav": false,
    "mouseDrag": true
  });